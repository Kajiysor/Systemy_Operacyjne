#ifndef FUNKCJA_H   // zapewnia najwyzej jednokrotne wlaczenie tego pliku
#define FUNKCJA_H 

// Przykladowa funkcja dwoch zmiennych: x*y 
double xy(double x,double y);

#endif
