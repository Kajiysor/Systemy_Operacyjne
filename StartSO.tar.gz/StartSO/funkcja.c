#include "funkcja.h"

// Przykladowa funkcja dwoch zmiennych: x*y
double xy(double x,double y)
{
  return x*y; 
}                  
